import pandas as pd


def apply_filters(df, year_range=None, min_cases=None, search_text=""):
    """Apply linked filters to the Pakistan malaria dataset."""
    data = df.copy()
    if year_range is not None:
        start, end = year_range
        data = data[(data["Year"] >= start) & (data["Year"] <= end)]
    if min_cases is not None:
        data = data[data["Estimated malaria cases per 1,000 population"] >= min_cases]
    if search_text:
        text = str(search_text).lower().strip()
        data = data[data.apply(lambda row: text in " ".join(row.astype(str)).lower(), axis=1)]
    return data
