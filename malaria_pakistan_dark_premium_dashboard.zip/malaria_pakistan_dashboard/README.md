# Pakistan Malaria Premium Dashboard

A dark, professional Streamlit dashboard for country-level Pakistan malaria cases and deaths since 2000 using WHO Global Health Observatory data.

## Features

- Pakistan-only malaria dashboard since 2000
- Built with Python, Pandas, Matplotlib, Seaborn, and Streamlit
- Premium dark UI theme
- KPI summary cards
- Dynamic filters connected to all charts
- Required chart types: pie chart, histogram, line chart, bar chart, scatter plot, box plot, heatmap, area chart, count plot, and violin plot
- Clean project structure for EDA submission

## How to Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Project Files

```text
malaria_pakistan_dashboard/
├── data/
│   ├── RELAY_WHS.csv
│   ├── GHE_FULL_DD.csv
│   └── 586_Pakistan.zip
├── notebooks/
│   └── analysis.ipynb
├── .streamlit/
│   └── config.toml
├── app.py
├── charts.py
├── filters.py
├── requirements.txt
└── README.md
```

## Main Insight

The dashboard helps identify malaria trend changes, high-risk years, case-rate distribution, uncertainty ranges, and the relationship between malaria case rates and death-rate indicators for Pakistan.
