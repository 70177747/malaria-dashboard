import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# Premium dark theme for Matplotlib/Seaborn charts
BG = "#0B1220"
PANEL = "#111827"
GRID = "#23314A"
TEXT = "#E5E7EB"
MUTED = "#9CA3AF"
CYAN = "#22D3EE"
BLUE = "#60A5FA"
PURPLE = "#A78BFA"
PINK = "#F472B6"
GREEN = "#34D399"
YELLOW = "#FBBF24"
RED = "#FB7185"

sns.set_theme(style="darkgrid")
plt.rcParams.update({
    "figure.facecolor": PANEL,
    "axes.facecolor": PANEL,
    "savefig.facecolor": PANEL,
    "axes.edgecolor": GRID,
    "axes.labelcolor": TEXT,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "text.color": TEXT,
    "axes.titlecolor": TEXT,
    "grid.color": GRID,
    "legend.facecolor": "#0F172A",
    "legend.edgecolor": GRID,
    "font.size": 10,
})

CASE_COL = "Estimated malaria cases per 1,000 population"
DEATH_COL = "Deaths rate per 100,000"


def _finish(fig, ax=None):
    if ax is not None:
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_color(GRID)
        ax.spines["bottom"].set_color(GRID)
        ax.title.set_fontweight("bold")
    fig.tight_layout()
    return fig


def line_chart(df):
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(df["Year"], df[CASE_COL], marker="o", linewidth=3, color=CYAN, label="Estimated cases")
    if {"Lower uncertainty", "Upper uncertainty"}.issubset(df.columns):
        ax.fill_between(df["Year"], df["Lower uncertainty"], df["Upper uncertainty"], alpha=0.18, color=CYAN, label="Uncertainty range")
    ax.set_title("Pakistan Malaria Case Trend Since 2000")
    ax.set_xlabel("Year")
    ax.set_ylabel("Cases per 1,000 population")
    ax.legend()
    return _finish(fig, ax)


def bar_chart(df):
    fig, ax = plt.subplots(figsize=(11, 5))
    top = df.sort_values(CASE_COL, ascending=False).head(10)
    sns.barplot(data=top, x="Year", y=CASE_COL, ax=ax, color=BLUE)
    ax.set_title("Top 10 Highest Malaria Case Years in Pakistan")
    ax.set_xlabel("Year")
    ax.set_ylabel("Cases per 1,000 population")
    ax.tick_params(axis="x", rotation=35)
    return _finish(fig, ax)


def histogram(df):
    fig, ax = plt.subplots(figsize=(11, 5))
    sns.histplot(df[CASE_COL], bins=10, kde=True, ax=ax, color=GREEN, edgecolor=BG)
    ax.set_title("Distribution of Malaria Case Rates")
    ax.set_xlabel("Cases per 1,000 population")
    ax.set_ylabel("Frequency")
    return _finish(fig, ax)


def scatter_plot(df):
    fig, ax = plt.subplots(figsize=(11, 5))
    sns.scatterplot(data=df, x="Year", y=CASE_COL, size="Uncertainty width", sizes=(70, 320), ax=ax, color=PINK, edgecolor=TEXT, linewidth=0.6, legend=True)
    ax.set_title("Yearly Malaria Rates and Uncertainty Width")
    ax.set_xlabel("Year")
    ax.set_ylabel("Cases per 1,000 population")
    return _finish(fig, ax)


def box_plot(df):
    fig, ax = plt.subplots(figsize=(9, 5))
    sns.boxplot(y=df[CASE_COL], ax=ax, color=PURPLE, width=0.35)
    sns.stripplot(y=df[CASE_COL], ax=ax, color=CYAN, size=5, alpha=0.65)
    ax.set_title("Spread, Median and Outliers of Case Rates")
    ax.set_ylabel("Cases per 1,000 population")
    return _finish(fig, ax)


def heatmap(df):
    fig, ax = plt.subplots(figsize=(10, 6))
    cols = ["Year", CASE_COL, "Lower uncertainty", "Upper uncertainty", "Uncertainty width", DEATH_COL]
    cols = [c for c in cols if c in df.columns]
    corr = df[cols].corr(numeric_only=True)
    sns.heatmap(corr, annot=True, cmap="mako", fmt=".2f", ax=ax, linewidths=0.5, linecolor=GRID, cbar_kws={"shrink": .75})
    ax.set_title("Correlation Heatmap")
    return _finish(fig, ax)


def area_chart(df):
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.fill_between(df["Year"], df[CASE_COL], color=CYAN, alpha=0.28, label="Cases")
    ax.plot(df["Year"], df[CASE_COL], color=CYAN, linewidth=2.5)
    ax.set_title("Area Chart: Malaria Burden Over Time")
    ax.set_xlabel("Year")
    ax.set_ylabel("Cases per 1,000 population")
    ax.legend(loc="upper left")
    return _finish(fig, ax)


def count_plot(df):
    fig, ax = plt.subplots(figsize=(10, 5))
    order = ["Low", "Medium", "High"]
    sns.countplot(data=df, x="Risk Category", order=order, ax=ax, palette=[GREEN, YELLOW, RED], hue="Risk Category", legend=False)
    ax.set_title("Count Plot: Years by Risk Category")
    ax.set_xlabel("Risk Category")
    ax.set_ylabel("Number of Years")
    return _finish(fig, ax)


def violin_plot(df):
    fig, ax = plt.subplots(figsize=(10, 5))
    order = ["Low", "Medium", "High"]
    sns.violinplot(data=df, x="Risk Category", y=CASE_COL, order=order, ax=ax, palette=[GREEN, YELLOW, RED], hue="Risk Category", legend=False, inner="quartile")
    ax.set_title("Violin Plot: Case Rate Density by Risk Category")
    ax.set_xlabel("Risk Category")
    ax.set_ylabel("Cases per 1,000 population")
    return _finish(fig, ax)


def pie_chart(df):
    fig, ax = plt.subplots(figsize=(8, 5.5))
    counts = df["Risk Category"].value_counts().reindex(["Low", "Medium", "High"]).fillna(0)
    wedges, texts, autotexts = ax.pie(
        counts,
        labels=counts.index,
        autopct=lambda p: f"{p:.1f}%" if p > 0 else "",
        startangle=90,
        colors=[GREEN, YELLOW, RED],
        wedgeprops={"linewidth": 1, "edgecolor": BG},
        textprops={"color": TEXT},
    )
    for t in autotexts:
        t.set_color(BG)
        t.set_fontweight("bold")
    ax.set_title("Pie Chart: Risk Category Share")
    return _finish(fig, ax)
