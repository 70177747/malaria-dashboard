import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

import charts
from filters import apply_filters

st.set_page_config(
    page_title="Pakistan Malaria Premium Dashboard",
    page_icon="🦟",
    layout="wide",
    initial_sidebar_state="expanded",
)

DATA_DIR = Path(__file__).parent / "data"
CASE_COL = "Estimated malaria cases per 1,000 population"
DEATH_COL = "Deaths rate per 100,000"


@st.cache_data(show_spinner=False)
def load_pakistan_malaria_data():
    relay_path = DATA_DIR / "RELAY_WHS.csv"
    deaths_path = DATA_DIR / "GHE_FULL_DD.csv"
    zip_path = DATA_DIR / "586_Pakistan.zip"

    relay = pd.read_csv(relay_path)
    relay = relay[relay["GEO_NAME_SHORT"].astype(str).str.lower().eq("pakistan")].copy()
    relay = relay[pd.to_numeric(relay["DIM_TIME"], errors="coerce") >= 2000].copy()
    relay = relay.rename(columns={
        "DIM_TIME": "Year",
        "RATE_PER_1000_N": CASE_COL,
        "RATE_PER_1000_NL": "Lower uncertainty",
        "RATE_PER_1000_NU": "Upper uncertainty",
        "GEO_NAME_SHORT": "Country",
        "IND_NAME": "Indicator",
    })
    relay["Year"] = relay["Year"].astype(int)
    keep = ["Country", "Indicator", "Year", CASE_COL, "Lower uncertainty", "Upper uncertainty"]
    relay = relay[keep]

    if zip_path.exists():
        try:
            with zipfile.ZipFile(zip_path) as z:
                malaria_files = [n for n in z.namelist() if n.endswith("_Dataset_2024-03-08.csv") and "Malaria" in n]
                relay["Pakistan ZIP source rows"] = 0
                if malaria_files:
                    with z.open(malaria_files[0]) as f:
                        zip_malaria = pd.read_csv(f)
                    relay["Pakistan ZIP source rows"] = len(zip_malaria)
        except Exception:
            relay["Pakistan ZIP source rows"] = 0

    deaths = pd.read_csv(deaths_path)
    deaths = deaths[(deaths["DIM_COUNTRY_CODE"] == "PAK") & (deaths["DIM_GHECAUSE_TITLE"].astype(str).str.lower() == "malaria")].copy()
    deaths = deaths.rename(columns={"DIM_YEAR_CODE": "Year", "VAL_DTHS_RATE100K_NUMERIC": DEATH_COL})
    deaths = deaths.groupby("Year", as_index=False)[DEATH_COL].mean()

    df = relay.merge(deaths, on="Year", how="left")
    df[DEATH_COL] = df[DEATH_COL].fillna(0)
    df["Uncertainty width"] = df["Upper uncertainty"] - df["Lower uncertainty"]
    df["Risk Category"] = pd.cut(
        df[CASE_COL],
        bins=[-np.inf, 5, 10, np.inf],
        labels=["Low", "Medium", "High"],
    ).astype(str)
    return df.sort_values("Year").reset_index(drop=True)


df = load_pakistan_malaria_data()

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');
:root { --bg:#070B14; --panel:#0F172A; --panel2:#111827; --line:#243047; --text:#E5E7EB; --muted:#94A3B8; --cyan:#22D3EE; --blue:#60A5FA; --pink:#F472B6; --green:#34D399; }
html, body, [class*="css"] { font-family: 'Inter', sans-serif; }
.stApp { background: radial-gradient(circle at top left, rgba(34,211,238,.16), transparent 30%), radial-gradient(circle at top right, rgba(244,114,182,.12), transparent 25%), linear-gradient(135deg, #070B14 0%, #0B1220 55%, #020617 100%); color: var(--text); }
.block-container { padding-top: 1.2rem; padding-bottom: 2rem; max-width: 1450px; }
[data-testid="stSidebar"] { background: linear-gradient(180deg, #0B1220 0%, #020617 100%); border-right: 1px solid var(--line); }
[data-testid="stSidebar"] * { color: var(--text); }
.hero { padding: 28px 30px; border: 1px solid rgba(96,165,250,.22); border-radius: 26px; background: linear-gradient(135deg, rgba(15,23,42,.92), rgba(17,24,39,.74)); box-shadow: 0 24px 60px rgba(0,0,0,.35); margin-bottom: 22px; }
.hero h1 { font-size: 2.35rem; margin:0 0 6px 0; font-weight:800; letter-spacing:-.04em; }
.hero p { color: var(--muted); font-size: 1rem; margin:0; }
.badge { display:inline-block; padding: 7px 12px; margin-bottom: 12px; border-radius: 999px; background: rgba(34,211,238,.12); color: var(--cyan); border: 1px solid rgba(34,211,238,.25); font-weight: 700; font-size:.82rem; }
.card { border:1px solid rgba(148,163,184,.18); border-radius:22px; background:rgba(15,23,42,.78); padding:18px; box-shadow: 0 18px 45px rgba(0,0,0,.22); }
.metric-card { border:1px solid rgba(148,163,184,.18); border-radius:22px; padding:18px; background: linear-gradient(135deg, rgba(15,23,42,.88), rgba(30,41,59,.54)); box-shadow: inset 0 1px 0 rgba(255,255,255,.04), 0 16px 38px rgba(0,0,0,.28); }
.metric-label { color:#94A3B8; font-size:.85rem; font-weight:700; text-transform:uppercase; letter-spacing:.05em; }
.metric-value { color:#F8FAFC; font-size:1.9rem; font-weight:800; margin-top:6px; }
.metric-help { color:#64748B; font-size:.78rem; margin-top:4px; }
h2, h3 { color:#F8FAFC; letter-spacing:-.02em; }
[data-testid="stMetricValue"] { color:#F8FAFC; }
.stTabs [data-baseweb="tab-list"] { gap: 10px; }
.stTabs [data-baseweb="tab"] { background: rgba(15,23,42,.8); border:1px solid rgba(148,163,184,.17); border-radius: 999px; padding: 10px 18px; }
.stTabs [aria-selected="true"] { background: linear-gradient(90deg, rgba(34,211,238,.25), rgba(96,165,250,.25)); color:white; }
[data-testid="stDataFrame"] { border:1px solid rgba(148,163,184,.18); border-radius: 18px; overflow:hidden; }
hr { border-color: rgba(148,163,184,.16); }
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <div class="badge">WHO Global Health Observatory • Pakistan • Since 2000</div>
  <h1>🦟 Pakistan Malaria Premium Dashboard</h1>
  <p>Dark professional Streamlit dashboard using Python, Pandas, Matplotlib and Seaborn. All charts are connected with filters and update dynamically.</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("### ⚙️ Dashboard Filters")
    year_min, year_max = int(df["Year"].min()), int(df["Year"].max())
    year_range = st.slider("Date / Year Range", year_min, year_max, (year_min, year_max))
    category_filter = st.multiselect("Category Filter: Risk Category", ["Low", "Medium", "High"], default=["Low", "Medium", "High"])
    min_case, max_case = float(df[CASE_COL].min()), float(df[CASE_COL].max())
    case_range = st.slider("Numerical Range: Case rate", min_case, max_case, (min_case, max_case), 0.1)
    death_range = st.slider("Numerical Range: Death rate", float(df[DEATH_COL].min()), float(df[DEATH_COL].max()), (float(df[DEATH_COL].min()), float(df[DEATH_COL].max())), 0.01)
    search_text = st.text_input("Search / Text Filter", "")
    show_data = st.toggle("Show filtered data table", True)
    if st.button("Reset / Clear Filters", use_container_width=True):
        st.rerun()

filtered = apply_filters(df, year_range=year_range, min_cases=case_range[0], search_text=search_text)
filtered = filtered[
    (filtered["Risk Category"].isin(category_filter)) &
    (filtered[CASE_COL].between(case_range[0], case_range[1])) &
    (filtered[DEATH_COL].between(death_range[0], death_range[1]))
]

if filtered.empty:
    st.warning("No records match the selected filters. Please reset filters.")
    st.stop()

peak_row = filtered.loc[filtered[CASE_COL].idxmax()]
low_row = filtered.loc[filtered[CASE_COL].idxmin()]
latest_row = filtered.sort_values("Year").iloc[-1]

k1, k2, k3, k4, k5 = st.columns(5)
metrics = [
    ("Total Records", f"{len(filtered):,}", "Filtered rows"),
    ("Average Case Rate", f"{filtered[CASE_COL].mean():.2f}", "per 1,000 population"),
    ("Peak Year", f"{int(peak_row['Year'])}", f"{peak_row[CASE_COL]:.2f} cases/1k"),
    ("Lowest Year", f"{int(low_row['Year'])}", f"{low_row[CASE_COL]:.2f} cases/1k"),
    ("Latest Death Rate", f"{latest_row[DEATH_COL]:.2f}", "per 100,000"),
]
for col, (label, value, help_text) in zip([k1, k2, k3, k4, k5], metrics):
    with col:
        st.markdown(f"""<div class='metric-card'><div class='metric-label'>{label}</div><div class='metric-value'>{value}</div><div class='metric-help'>{help_text}</div></div>""", unsafe_allow_html=True)

st.markdown("---")

if show_data:
    st.markdown("### 📋 Filtered Pakistan Malaria Dataset")
    st.dataframe(filtered, use_container_width=True, height=300)

st.markdown("### 📊 Required Professional Visualizations")

tab1, tab2, tab3, tab4, tab5 = st.tabs(["📈 Trend", "🏆 Comparison", "📦 Distribution", "🔗 Relationship", "🧠 Correlation"])

with tab1:
    col1, col2 = st.columns(2)
    with col1:
        st.pyplot(charts.line_chart(filtered), use_container_width=True)
    with col2:
        st.pyplot(charts.area_chart(filtered), use_container_width=True)

with tab2:
    col1, col2 = st.columns(2)
    with col1:
        st.pyplot(charts.bar_chart(filtered), use_container_width=True)
    with col2:
        st.pyplot(charts.pie_chart(filtered), use_container_width=True)
    st.pyplot(charts.count_plot(filtered), use_container_width=True)

with tab3:
    col1, col2 = st.columns(2)
    with col1:
        st.pyplot(charts.histogram(filtered), use_container_width=True)
    with col2:
        st.pyplot(charts.box_plot(filtered), use_container_width=True)
    st.pyplot(charts.violin_plot(filtered), use_container_width=True)

with tab4:
    st.pyplot(charts.scatter_plot(filtered), use_container_width=True)

with tab5:
    st.pyplot(charts.heatmap(filtered), use_container_width=True)

st.markdown("### 💡 Brief Insights")
st.markdown(f"""
<div class='card'>
<b>Highest burden:</b> {int(peak_row['Year'])} has the highest filtered malaria case rate at <b>{peak_row[CASE_COL]:.2f}</b> cases per 1,000 population.<br>
<b>Lowest burden:</b> {int(low_row['Year'])} has the lowest filtered case rate at <b>{low_row[CASE_COL]:.2f}</b> cases per 1,000 population.<br>
<b>Dashboard rule:</b> year, category, numerical range and search filters are connected to every visualization.
</div>
""", unsafe_allow_html=True)
