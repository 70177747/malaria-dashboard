@echo off
title Pakistan Malaria Premium Dashboard
cd /d %~dp0
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
streamlit run app.py
pause
