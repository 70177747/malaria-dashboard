# Pakistan Malaria Premium Streamlit Dashboard

A modern, responsive, interactive EDA dashboard for the malaria dataset.

## Features
- KPI summary cards
- Linked sidebar filters
- Theme switcher
- Mobile responsive Streamlit layout
- Pie chart, histogram, line chart, bar chart, scatter plot, box plot, heatmap, area chart, count plot and violin plot
- Download filtered CSV
- Uses Pandas, NumPy, Matplotlib, Seaborn, Plotly and Streamlit

## Local Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Streamlit Cloud Deploy
1. Upload this full folder to a GitHub repository.
2. Go to Streamlit Community Cloud.
3. Select the repository.
4. Main file path: `app.py`
5. Click Deploy.

Important: Dataset filenames are kept unchanged in the `data` folder.
